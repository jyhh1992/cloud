a = 19
b= 1

print[a  + b]
print[a - b]
